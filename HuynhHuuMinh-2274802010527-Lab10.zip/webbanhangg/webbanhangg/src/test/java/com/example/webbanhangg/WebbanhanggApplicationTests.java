package com.example.webbanhangg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebbanhanggApplicationTests {

	@Test
	void contextLoads() {
	}

}
